package com.tap.model;

import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;


public class MailItemReader implements ItemReader<Person>{

	@Override
	public Person read() throws Exception, UnexpectedInputException,
			ParseException, NonTransientResourceException {
		Person person=new Person();
		// TODO Auto-generated method stub
		return person;
	}

}
