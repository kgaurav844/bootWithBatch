package com.tap.job;

import java.util.Date;

import org.quartz.InterruptableJob;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.JobKey;
import org.quartz.UnableToInterruptJobException;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.quartz.QuartzJobBean;

import com.techprimers.security.jwtsecurity.security.JobService;

public class CronJob extends QuartzJobBean implements InterruptableJob{
	
	private volatile boolean toStopFlag = true;
	
	@Autowired
	JobService jobService;
	
	 @Autowired
	    JobLauncher jobLauncher;
	 
	    @Autowired
	    private ApplicationContext context;  
	    
	@Override
	protected void executeInternal(JobExecutionContext jobExecutionContext) throws JobExecutionException {
		JobKey key = jobExecutionContext.getJobDetail().getKey();
		System.out.println("Cron Job started with key :" + key.getName() + ", Group :"+key.getGroup() + " , Thread Name :"+Thread.currentThread().getName() + " ,Time now :"+new Date());
		
		/*System.out.println("======================================");
		System.out.println("Accessing annotation example: "+jobService.getAllJobs());
		List<Map<String, Object>> list = jobService.getAllJobs();
		System.out.println("Job list :"+list);
		System.out.println("======================================");
		*/
		//*********** For retrieving stored key-value pairs ***********/
		/*JobDataMap dataMap = jobExecutionContext.getMergedJobDataMap();
		String myValue = dataMap.getString("myKey");
		System.out.println("Value:" + myValue);

		System.out.println("Thread: "+ Thread.currentThread().getName() +" stopped.");
		
		*/
		Job job1 = (Job) context.getBean("demoJob1");
		
		 
		 JobParameters params = new JobParametersBuilder()
         .addString("JobID", String.valueOf(System.currentTimeMillis()))
         .toJobParameters();
try {
	//jobLauncher.run(addNewPodcastJob, params);
	jobLauncher.run(job1, params);
	System.out.println("==================<<<<<<<>>>>>>>>>>====================");
} catch (JobExecutionAlreadyRunningException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (JobRestartException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (JobInstanceAlreadyCompleteException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (JobParametersInvalidException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

	}

	@Override
	public void interrupt() throws UnableToInterruptJobException {
		System.out.println("Stopping thread... ");
		toStopFlag = false;
	}

}