package com.techprimers.security.jwtsecurity.security;

import java.util.Calendar;
import java.util.Date;

import com.techprimers.security.jwtsecurity.model.JwtUser;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import org.springframework.stereotype.Component;

@Component
public class JwtGenerator {

    public String generate(JwtUser jwtUser) {

    	System.out.println("333333");
    	 Date currentDate = new Date();
         // convert date to calendar
         Calendar c = Calendar.getInstance();
         c.setTime(currentDate);
         // manipulate date
         //c.add(Calendar.YEAR, 1);
         //c.add(Calendar.MONTH, 1);
         //c.add(Calendar.DATE, 1); 
         //c.add(Calendar.HOUR, 1);
         c.add(Calendar.MINUTE, 10);
         //c.add(Calendar.SECOND, 1);

         // convert calendar to date
         Date currentDatePlusOne = c.getTime();
         
    	Claims claims = Jwts.claims()
        		.setIssuedAt(new Date())
                .setExpiration(currentDatePlusOne)
                .setSubject(jwtUser.getUserName());
        
        claims.put("userId", String.valueOf(jwtUser.getId()));
        claims.put("role", jwtUser.getRole());
        
        return Jwts.builder()
                .setClaims(claims)
                .signWith(SignatureAlgorithm.HS256, "tcstap")
                .compact();
    }
}
