package com.techprimers.security.jwtsecurity.controller;

import com.techprimers.security.jwtsecurity.model.JwtUser;
import com.techprimers.security.jwtsecurity.security.JwtGenerator;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/token")
@CrossOrigin(origins = "http://localhost:4200")
public class TokenController {


    private JwtGenerator jwtGenerator;

    public TokenController(JwtGenerator jwtGenerator) {
    	System.out.println("222222");
        this.jwtGenerator = jwtGenerator;
    }

   /* @PostMapping
    public String generate(@RequestBody final JwtUser jwtUser) {
    	System.out.println("1111111111111111");
    	
        return jwtGenerator.generate(jwtUser);

    }*/
    
    @PostMapping
    public JwtToken generate(@RequestBody final JwtUser jwtUser) {
    	
    	 return new JwtToken(jwtGenerator.generate(jwtUser));
    	 
    	
      //  return jwtGenerator.generate(jwtUser);

    }
    
}
