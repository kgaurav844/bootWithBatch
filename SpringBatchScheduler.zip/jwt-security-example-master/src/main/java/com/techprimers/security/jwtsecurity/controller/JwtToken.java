package com.techprimers.security.jwtsecurity.controller;

public class JwtToken {

	private final String jwttoken;
	
	public JwtToken(String jwttoken) {
        this.jwttoken = jwttoken;
    }

    public String getJwttoken() {
        return jwttoken;
    }
}
