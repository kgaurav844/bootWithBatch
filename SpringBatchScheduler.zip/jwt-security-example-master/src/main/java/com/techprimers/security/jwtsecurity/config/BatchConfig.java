package com.techprimers.security.jwtsecurity.config;

import org.quartz.DisallowConcurrentExecution;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.tap.model.Person;
import com.tap.task.MyTaskOne;
import com.tap.task.MyTaskTwo;
import com.tap.model.MailItemReader;

@Configuration
@EnableBatchProcessing
@DisallowConcurrentExecution
public class BatchConfig {
     
    @Autowired
    private JobBuilderFactory jobs;
 
    @Autowired
    private StepBuilderFactory steps;
     
    @Bean
    public Step stepOne(){
        return steps.get("stepOne")
                .tasklet(new MyTaskOne())
                .build();
    }
     
    @Bean
    public Step stepTwo(){
        return steps.get("stepTwo")
                .tasklet(new MyTaskTwo())
                .build();
    }  
     
    @Bean
    @Primary
    public Job demoJob(){
        return jobs.get("demoJob")
                .incrementer(new RunIdIncrementer())
                .start(stepOne())
                .next(stepTwo())
                .build();
    }
    
    @Bean
    public Job demoJob1(){
        return jobs.get("demoJob1")
                .incrementer(new RunIdIncrementer())
                .start(stepTwo())
                //.next(stepTwo())
                .build();
    }
    
    
   /* @Bean
    public Job capitalizeNamesJob(JobBuilderFactory jobBuilders, StepBuilderFactory stepBuilders) {
      return jobBuilders.get("EmailNotificationJob")
          .start(readMailTemplateStep(stepBuilders))
          .build();
          //.next(sendMailStep(stepBuilders)).build();
    }
    
    
    @Bean
    public Step readMailTemplateStep(StepBuilderFactory stepBuilders) {
      return stepBuilders.get("MailTemplateStep")
          .<Person, Person>chunk(10).reader(MailItemReader())
          .processor(MailItemProcessor()).writer(MailItemWriter()).build();
    }
*/
 
    
    
    
}